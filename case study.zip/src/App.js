import React from "react";
import MainScreen from "./component/MainScreen";
import Navbar from "./component/Navbar.js";
import "./App.css";
import Login from "./Login/Login.js";
import Home from "./screens/Home.js";
import {BrowserRouter as Router , Routes , Route, Link} from 'react-router-dom';
import Batch from "./screens/Batch";
import BatchTable from "./screens/BatchTable.js";
import { Demo } from "./Demo/Demo.js";
import AddBatches from "./screens/AddBatches"
import TimeSheet from "./screens/TimeSheet";
import Dashboard from "./component/Dashboard";
function App() {
  return (
    <div>

    
    <Router>
     
      <Dashboard/>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/mainscreen" element={<MainScreen/>}/>
          <Route path="/batch" element={<Batch/>}/>
          <Route path="/addbatch" element={<AddBatches/>}/>
          <Route path="/timeSheet" element={<TimeSheet/>}/>
        </Routes>
        
    </Router>
    </div>
  );
}

export default App;
