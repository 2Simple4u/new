import React from "react";
import "./AddBatches.css";

function AddBatches() {
  return (
    <div className="parent_addBatches">
      <div className="addbatches_topBar">
        <h2>Information of Batches</h2>
      </div>
      <div className="addBatches_data">
        <div className="col-1">
          <div className="curriculam child-col-1">
            <label htmlFor="curriculum">
              Curriculum <span className="star">*</span>
            </label>
            <input type="text" name="curriculum" id="curriculum" />
          </div>
          <div className="Session child-col-1">
            <label htmlFor="Session">
              Session <span className="star">*</span>
            </label>
            <input type="text" name="Session" id="Session" />
          </div>
        </div>
        <div className="col-1">
          <div className="Name child-col-1">
            <label htmlFor="Name">
              Name <span className="star">*</span>
            </label>
            <input type="text" name="Name" id="Name" />
          </div>
          <div className="Trainer child-col-1">
            <label htmlFor="Trainer">
              Trainer <span className="star">*</span>
            </label>
            <input type="text" name="trainer" id="Trainer" />
          </div>
        </div>
        <div className="col-1">
          <div className="Time child-col-1">
            <label htmlFor="Time">
              Time <span className="star">*</span>
            </label>
            <div className="col-date">
                {/* <label htmlFor="startDate" className="child-date">Start</label> */}
              <input type="time" name="StartTime" id="Time" />
              {/* <label htmlFor="endDate" className="child-date">End </label> */}
              <input type="time" name="EndTime" id="Time" />
            </div>
          </div>
          <div className="Date child-col-1">
            <label htmlFor="Date">
              Date <span className="star">*</span>
            </label>
            <div className="col-date">
            {/* <label htmlFor="startDate" className="child-date">Start </label> */}
              <input type="date" name="startDate" id="Date" />
              {/* <label htmlFor="startDate" className="child-date">End</label> */}
              <input type="date" name="EndDate" id="Date" />
            </div>
          </div>
        </div>

        <div className="description child-col-1">
          <label htmlFor="description">Description</label>
          <textarea
            name="Description"
            id="description"
            cols="30"
            rows="10"
          ></textarea>
        </div>
        <div className="buttons">
          <button className="create_button">Create</button>
          <button className="cancel_button">Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default AddBatches;
