import React from "react";
import "./BatchTable.css"

function BatchTable({batch}) {
  return (
    <div className="parent_batchTable">
      <div className="batches_data">
        <h2>{batch.title}</h2>
        <p>Session</p>
        <table className="batches_data_table">
          <thead>
            <tr>
              <th>Actions</th>
              <th>Batch</th>
              <th>Dates</th>
              <th>Time</th>
              <th>Trainer</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
            </tr>
            <tr>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
            </tr>
            <tr>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
              <td>11</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default BatchTable;
