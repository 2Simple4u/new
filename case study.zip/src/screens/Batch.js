import React, {useState}from "react";
import { useNavigate } from "react-router-dom";
import "./Batch.css"
import BatchTable from "./BatchTable.js";

function Batch  () {
  let navigate = useNavigate();
  const [batchTable, setBatchTable] = useState([
    {title:"JFS"},
    {title:"MEAN"},
  ]);
  return (
    <div className="main_Batch" href="/batch">
      <div className="batch_topbar">
        <h2>Batches</h2>
        <button type="submit" onClick={()=>navigate("/addbatch")}> + Add </button>
      </div>
      {
        batchTable.length > 0
        ? batchTable.map((item) => <BatchTable batch={item}/>)
        : "No Batches"
        
      }

    </div>
  );
}

export default Batch;
