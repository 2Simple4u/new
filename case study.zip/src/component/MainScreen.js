import React from "react";
import Batch from "../screens/Batch.js";
import Dashboard from "./Dashboard";
import Navbar from "./Navbar.js";
import "./style/Mainscreen.css";
import AddBatches from "../screens/AddBatches.js";
import { Link, Route, Router, Routes, useNavigate } from "react-router-dom";
import BatchTable from "../screens/BatchTable.js";
import TimeSheet from "../screens/TimeSheet.js";

function MainScreen() {
  let navigate = useNavigate();
  return (

    
    <div className="main_screen">
      <Navbar />
      <div className="parent-panel">
        <div className="left-panel">
          <Dashboard />
        </div>
        

        
        <div className="right-panel">
          <Batch/>
        </div>  
         
      </div>
    </div>
  );
}

export default MainScreen;
