import React from "react";
import AssessmentIcon from "@mui/icons-material/Assessment";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import AnalyticsIcon from "@mui/icons-material/Analytics";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import "./style/Dashboard.css";
import { BrowserRouter, Link, Routes,Route, useNavigate } from "react-router-dom";
import Batch from "../screens/Batch";
import Login from "../Login/Login.js";

import {
  BrowserRouter as Router,
  Switch,
  useRouteMatch
} from "react-router-dom";


function Dashboard() {
  return (
      <div className="MainBar">
        <div className="Side_bar">
          <div className="Dashboard_text">
            <h2>Dashboard</h2>
          </div>
          <div className="Batch_Manage_bar">
            <AssessmentIcon fontSize="large" />
              {/* <h2>Manage Batch</h2> */}
              <Link tag="a" to="/batch">Manage batch</Link>
          </div>
          <div className="TimeSheet_Manage_bar">
            <CalendarTodayIcon fontSize="large" />
            {/* <h2 >Timesheet</h2> */}
            <Link tag="a" to="/timesheet">TimeSheet</Link>
          </div>
          <div className="Report_Manage_bar">
            <AnalyticsIcon fontSize="large" />
            <h2>Report</h2>
          </div>
        </div>
      </div>
  );
}

export default Dashboard;
